var CWJ_GLOBAL_API = {
    "BASE_URL":"//127.0.0.1:9000"
}